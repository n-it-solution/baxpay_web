<?php
/**
 * Created by PhpStorm.
 * User: angopapo
 * Date: 27/08/18
 * Time: 11:52
 */

namespace App\Controller\home;



use App\Entity\Currency;
use App\Entity\Transaction;
use App\Entity\User;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;

class HomeController extends AbstractController
{

    /**
     * @Route("/", defaults={"_locale":"%locale%"}, name="homepage")
     * @Route("/{_locale}/",requirements={"_locale":"%app_locales%"})
     * @Method("GET")
     */

    /**
     * @Route("/", name="homepage")
     */

    public function homepage(Request $request,\Swift_Mailer $mailer){
        if(!empty($this->getUser())){
            $error = '';
            $em = $this->getDoctrine()->getManager();
            if($request->getMethod() == 'POST'){
                $data = $request->request->all();
                if($data['sender'] == $this->getUser()->getUserName()){
                    $error = "You can't send money to own";
                }
                else{
                    $sender = $em->getRepository(User::class)->findOneBy(['username' => $data['sender'] , 'enabled' => 1]);
                    if(empty($sender)){
                        $error = 'Send username not found in database';
                    }
                    else{
                        $received = $em->getRepository(Transaction::class)->findByReceiver($this->getUser()->getId(),$data['currency']);
                        $sended = $em->getRepository(Transaction::class)->findBySender($this->getUser()->getId(),$data['currency']);
                        $total = $received[0][1]-$sended[0][1];
                        if($total >= $data['amount']){
                            $transaction = New Transaction();
                            $transaction->setAmount($data['amount']);
                            $transaction->setSender($this->getUser());
                            $transaction->setDescription($data['description']);
                            $transaction->setReceiver($sender);
                            $currency = $em->getRepository(Currency::class)->find($data['currency']);
                            $transaction->setCurrency($currency);
                            $transaction->setType(1);
                            $transaction->setDate(date('Y/m/d H:i:s'));
                            $em->persist($transaction);
                            $em->flush();
                            $error = 'Transaction send to ' . $sender->getFirstName() . ' ' . $sender->getLastName() . ' Successfully';
                            $message = (new \Swift_Message('Hello Email'))
                                ->setFrom('mirza.amanan@gmail.com')
                                ->setTo($sender->getEmail())
                                ->setBody(
                                    $this->renderView(
                                    // templates/emails/registration.html.twig
                                        'emails/trans.html.twig',
                                        [
                                            'name' => $this->getUser()->getFirstName().' '.$this->getUser()->getLastName(),
                                            'receiver' => $sender->getFirstName().' '.$sender->getLastName(),
                                            'amount' => $data['amount'],
                                            'currency' => $currency->getName()
                                        ]
                                    ),
                                    'text/html'
                                );
                            $mailer->send($message);
                        }else{
                            $error = "You don't have enough balance to send";
                        }

                    }
                }
            }
            $currency = $em->getRepository(Currency::class)->findAll();
            return $this->render('home/homepage.html.twig', [
                'currency' => $currency,
                'error' => $error,
            ]);
        }
        else{
            return $this->redirectToRoute('fos_user_security_login');
        }
    }

    /**
     * @Route("/menu", name="menu")
     */
    public function menu(){

        //return new Response('Bemvindo ao Baxpay');
        return $this->render('partials/menu.html.twig');
    }

    /**
     * @Route("/footer", name="footer")
     */
    public function footer(){

        //return new Response('Bemvindo ao Baxpay');
        return $this->render('partials/footer.html.twig');
    }

    /**
     * @Route("/dash", name="dash")
     */
    public function dash(){
        $currency = $this->getDoctrine()->getRepository(Currency::class)->findAll();
        $usd = $this->getDoctrine()->getRepository(Transaction::class)->findInReceiverAndSender($this->getUser()->getId(),1);
        $eur = $this->getDoctrine()->getRepository(Transaction::class)->findInReceiverAndSender($this->getUser()->getId(),2);
        $gbp = $this->getDoctrine()->getRepository(Transaction::class)->findInReceiverAndSenderWithoutCurrency($this->getUser()->getId());
//        print_r($data);
        //return new Response('Bemvindo ao Baxpay');
        return $this->render('partials/dashboard.html.twig',['usd' => $usd,'eur' => $eur, 'gbp' => $gbp,'currency' => $currency,]);
    }

    /**
     * @Route("/404", name="page_not_found_404")
     */
    public function NotFound404(){

        //return new Response('Bemvindo ao Baxpay');
        return $this->render('partials/404.html.twig');
    }

    /**
     * @Route("/500", name="internal_server_error_500")
     */
    public function ServerError500(){

        //return new Response('Bemvindo ao Baxpay');
        return $this->render('partials/500.html.twig');
    }

    /**
     * @Route("/view/profile", name="user_view_profile")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function ViewProfile(){
        return $this->render('home/profile.html.twig');
    }


}